from socket import timeout
import traceback
from confluent_kafka import Consumer, KafkaException
import json
import traceback
import time

def deserialize(data):
    return json.loads(data.decode('latin-1'))

if __name__ == "__main__":
    #消费者配置
    conf_consumer = {'bootstrap.servers': '159.226.16.97:9092', 'group.id': 'dns-check',
             'auto.offset.reset': 'latest'}

    #初始化生产者和消费者
    consumer = Consumer(conf_consumer)
    consumer.subscribe(['TRANSACTION-RECORD'])
    i = 0
    '''
    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                raise KafkaException(msg.error())
            else:
                message = deserialize(msg.value())
                if 'common_schema_type' in message:
                    if (message['common_schema_type'] == 'DNS'):
                        if 'dns_qr' in message:
                            if(message['dns_qr'] == 1):
                                interval = (int(time.time())-int(message['common_start_time']))
                                if(int(time.time())-int(message['common_start_time'])>3600):
                                    print("interval is :"+str(interval))
                                    print(message)
    except Exception as e:
        traceback.print_exc()
    finally:
        consumer.close()
    '''
    num = 0
    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                raise KafkaException(msg.error())
            else:
                message = deserialize(msg.value())
                if 'common_schema_type' in message:
                    if (message['common_schema_type'] == 'DNS'):
                        if 'dns_qr' in message:
                            if(message['dns_qr'] == 1):
                                num = num + 1
                                print(message)
                            if(num > 10000):
                                break
    except Exception as e:
        traceback.print_exc()
    finally:
        consumer.close()
	
