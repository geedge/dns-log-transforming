from socket import timeout
import traceback
from confluent_kafka import Consumer, KafkaException
import json
import traceback

def deserialize(data):
    return json.loads(data.decode('latin-1'))

if __name__ == "__main__":
    #消费者配置
    conf_consumer = {'bootstrap.servers': '159.226.16.115:29097', 'group.id': 'dns-check',
             'auto.offset.reset': 'latest'}

    #初始化生产者和消费者
    consumer = Consumer(conf_consumer)
    consumer.subscribe(['DNS_BEHAVIOR_2022'])
    i = 0

    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                raise KafkaException(msg.error())
            else:
                message = deserialize(msg.value())
                if(int(message['timestamp'])<1646928000):
                    continue
                elif((int(message['timestamp'])>=1646928000)and(int(message['timestamp'])<=1647014400)):
                    i = i + 1
                    print("total:"+str(i))
                else:
                    continue
                                 
    except Exception as e:
        traceback.print_exc()
    finally:
        consumer.close()
